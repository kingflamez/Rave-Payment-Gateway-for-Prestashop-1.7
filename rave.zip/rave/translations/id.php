<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{rave}prestashop>intro_cfeb93836e40b2cd214a623477731f20'] = 'Barang akan disimpan untuk Anda selama %s hari dan akan diproses segera setelah pembayaran diterima.';
$_MODULE['<{rave}prestashop>intro_ab066b3292d8ab61ef3b5c77169cdd19'] = 'Informasi lainnya';
$_MODULE['<{rave}prestashop>intro_ee081b084fe92867c7c9ce8a0a32d81f'] = 'rave';
$_MODULE['<{rave}prestashop>intro_ebcdf354e92daa6f6dee8a83a14e5c7a'] = 'Pembayaran dllakukan melalui transfer ke rekening berikut:';
